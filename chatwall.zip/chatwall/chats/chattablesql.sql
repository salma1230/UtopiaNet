CREATE TABLE chat (
  cid int(11) not null AUTO_ONCREMENT PRIMARY KEY,
  uid VARCHAR(128) not null,
  date datetime not null,
  message TEXT not null
);
